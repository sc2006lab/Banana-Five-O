// Discovery, profile and comparison logic (UC-3.1, UC-4.1, UC-4.2, UC-6.1, UC-6.2).
import {
  AMENITY_CATEGORIES,
  CRITERIA,
  DEFAULT_WEIGHTS,
  LIMITATION_EDUCATION,
  LIMITATION_PROFILE,
  LIMITATION_SCORE,
  STAGE_CATEGORIES,
  type AmenityCategory,
  type AmenitySummaryDto,
  type CommuteDestination,
  type CriterionWeights,
  type FacilityDto,
  type FamilyStage,
  type NeighbourhoodDetail,
  type NeighbourhoodSummary,
  type ProximityRadius,
  type SearchResponse,
  type LocationOrigin,
} from '@famplan/shared';
import { DISTANCE_BASIS, haversineM, pointInBoundary, withinRadius } from '../lib/geo.js';
import { HttpError } from '../lib/http.js';
import { calculateScore } from '../scoring/score.js';
import { searchLocation } from '../travel/onemap.js';
import { postalCode } from '../travel/postal.js';
import { index, type IndexedNeighbourhood } from './store.js';

export interface ScoringContext {
  weights: CriterionWeights;
  thresholds: Partial<Record<AmenityCategory, ProximityRadius>>;
  destinations: CommuteDestination[];
  radius: ProximityRadius;
  origin?: LocationOrigin;
}

export function scoringContext(q: Record<string, unknown>): ScoringContext {
  const weights = Object.fromEntries(
    CRITERIA.map((c) => [c, typeof q[`w_${c}`] === 'number' ? (q[`w_${c}`] as number) : DEFAULT_WEIGHTS[c]]),
  ) as CriterionWeights;
  return {
    weights,
    thresholds: (q.th as ScoringContext['thresholds']) ?? {},
    destinations: (q.destinations as CommuteDestination[] | undefined) ?? [],
    radius: ((q.radius as number) ?? 1000) as ProximityRadius,
    origin: typeof q.originLat === 'number' && typeof q.originLng === 'number'
      ? { lat: q.originLat, lng: q.originLng, address: String(q.originAddress), postal: (q.originPostal as string) || null }
      : undefined,
  };
}

export function summarise(n: IndexedNeighbourhood, ctx: ScoringContext, category?: AmenityCategory): NeighbourhoodSummary {
  const score = calculateScore(index.evidence(n, scoreThresholds(ctx), ctx.destinations), ctx.weights, index.datasetVersions());
  const highlights = amenitySummaries(n, ctx.radius).map((a) => ({
    category: a.category,
    count: a.matchedCount,
    nearestM: a.nearest?.distanceM ?? null,
    state: a.state,
  }));
  return {
    id: n.id,
    name: n.name,
    planningArea: n.planningArea,
    region: n.region,
    lat: n.lat,
    lng: n.lng,
    score,
    coverage: highlights.filter((h) => h.count > 0).length,
    highlights,
    commuteMin: index.commuteMinutes(n, ctx.destinations),
    commuteLegs: index.commuteLegs(n, ctx.destinations),
    nearestSelectedM: category && index.categoryState(category).state !== 'UNAVAILABLE' && n.nearest[category] ? Math.round(n.nearest[category]!.d) : null,
    origin: ctx.origin,
  };
}

function scoreThresholds(ctx: ScoringContext) {
  return { ...Object.fromEntries(AMENITY_CATEGORIES.map((c) => [c, ctx.radius])), ...ctx.thresholds };
}

const norm = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');

export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let diag = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return prev[b.length];
}

/** Town / planning-area / subzone-name match with tolerance for small spelling variants (FR-DISC-01). */
export function nameMatches(n: { name: string; planningArea: string; region: string }, q: string): boolean {
  const nq = norm(q);
  if (!nq) return !q.trim();
  const fields = [n.name, n.planningArea, n.region.replace(/ Region$/, '')].map(norm);
  if (fields.some((f) => f.includes(nq))) return true;
  if (nq.length < 5) return false;
  const tol = nq.length >= 8 ? 2 : 1;
  return fields.some((f) => levenshtein(f, nq) <= tol || (f.length > nq.length && levenshtein(f.slice(0, nq.length), nq) <= tol));
}

export interface SearchParams extends ScoringContext {
  q: string;
  areas: string[];
  stages: FamilyStage[];
  category?: AmenityCategory;
  minCount?: number;
  maxNearest?: number;
  maxCommute?: number;
  sort: 'score' | 'nearest' | 'commute' | 'coverage';
  order?: 'asc' | 'desc';
  page: number;
  pageSize: number;
}

export async function searchNeighbourhoods(p: SearchParams): Promise<SearchResponse> {
  let pool = index.searchable;
  let matchedBy: SearchResponse['matchedBy'] = 'all';
  let addressMatch: SearchResponse['addressMatch'];

  let origin = p.origin;
  if (p.q && !origin) {
    if (!/[\p{L}\p{N}]/u.test(p.q)) throw new HttpError(400, 'Enter a place name, street address or six-digit postal code.', { q: 'Search must contain a name or postal code.' });
    // Reject malformed postcode-only inputs before fuzzy neighbourhood matching.
    const postal = postalCode(p.q);
    const byName = pool.filter((n) => nameMatches(n, p.q));
    const looksLikeAddress = /\d/.test(p.q);
    if (byName.length && !looksLikeAddress && !postal) {
      pool = byName;
      matchedBy = 'name';
    } else {
      // Address or postal code: geocode with OneMap, then rank neighbourhoods around the point.
      let hits;
      try {
        hits = await searchLocation(p.q, 20);
      } catch (error) {
        if (error instanceof HttpError) throw error;
        if (byName.length) {
          pool = byName;
          matchedBy = 'name';
          hits = null;
        } else
          throw new HttpError(503, 'Address search is temporarily unavailable. Search by town or area name instead.', {
            q: 'Try a town, planning area or estate name.',
          });
      }
      if (hits) {
        if (hits.length > 1) {
          return { total: 0, page: p.page, pageSize: p.pageSize, radius: p.radius, results: [], matchedBy: 'ambiguous', locationChoices: hits, limitation: LIMITATION_PROFILE };
        }
        const hit = hits[0];
        if (!hit) {
          if (looksLikeAddress)
            throw new HttpError(404, 'No Singapore address matches this postal code or address. Check the input and try again.', {
              q: 'Use the full six-digit postal code or a complete Singapore street address.',
            });
          pool = byName;
          matchedBy = 'name';
        } else {
          origin = { address: hit.address, lat: hit.lat, lng: hit.lng, postal: hit.postal };
        }
      }
    }
  }

  if (origin) {
    const containing = index.neighbourhoods.find((n) => pointInBoundary(origin!.lat, origin!.lng, n.boundary));
    const context = containing ?? index.neighbourhoods.reduce<IndexedNeighbourhood | undefined>((best, n) =>
      !best || haversineM(origin!.lat, origin!.lng, n.lat, n.lng) < haversineM(origin!.lat, origin!.lng, best.lat, best.lng) ? n : best, undefined);
    addressMatch = { ...origin, neighbourhoodId: containing?.id ?? null };
    // One exact address has one set of amenity evidence. Do not duplicate it across surrounding zones.
    pool = context ? [index.atPoint(context, origin)] : [];
    matchedBy = 'address';
  }
  const ctx = { ...p, origin };

  if (p.areas.length) {
    const set = new Set(p.areas.map((a) => a.toUpperCase()));
    pool = pool.filter((n) => set.has(n.planningArea.toUpperCase()));
  }
  for (const stage of p.stages) {
    const cats = STAGE_CATEGORIES[stage];
    pool = pool.filter((n) => index.countWithin(n, cats, p.radius) > 0);
  }
  if (p.category && p.minCount !== undefined) pool = pool.filter((n) => index.countWithin(n, [p.category!], p.radius) >= p.minCount!);
  if (p.category && p.maxNearest !== undefined) pool = pool.filter((n) => (n.nearest[p.category!]?.d ?? Infinity) <= p.maxNearest!);
  if (p.maxCommute !== undefined) pool = pool.filter((n) => (index.commuteMinutes(n, p.destinations) ?? Infinity) <= p.maxCommute!);

  let results = pool.map((n) => summarise(n, ctx, p.category));
  if (matchedBy !== 'address' || p.sort !== 'score' || p.order) {
    const dir = p.order ?? (p.sort === 'score' || p.sort === 'coverage' ? 'desc' : 'asc');
    const key = (r: NeighbourhoodSummary): number | null =>
      p.sort === 'score' ? r.score.total : p.sort === 'coverage' ? r.coverage : p.sort === 'commute' ? r.commuteMin : r.nearestSelectedM;
    // Unavailable values placed last regardless of direction; ties broken by name then id (stable pagination).
    results = results.sort((a, b) => {
      const ka = key(a);
      const kb = key(b);
      if (ka === null && kb !== null) return 1;
      if (kb === null && ka !== null) return -1;
      if (ka !== null && kb !== null && ka !== kb) return dir === 'asc' ? ka - kb : kb - ka;
      return a.name.localeCompare(b.name) || a.id.localeCompare(b.id);
    });
  }
  const total = results.length;
  const start = (p.page - 1) * p.pageSize;
  return {
    total,
    page: p.page,
    pageSize: p.pageSize,
    radius: p.radius,
    results: results.slice(start, start + p.pageSize),
    matchedBy,
    addressMatch,
    limitation: origin ? 'Counts, scores and straight-line distances use your selected address. Source coordinates may have positional inaccuracies; this is not a school-admission catchment assessment.' : LIMITATION_PROFILE,
  };
}

export function getNeighbourhood(id: string): IndexedNeighbourhood {
  const n = index.byId.get(id);
  if (!n) throw new HttpError(404, 'We could not find that neighbourhood. It may have been removed in a data update.');
  return n;
}

export function amenitySummaries(n: IndexedNeighbourhood, radius: ProximityRadius): AmenitySummaryDto[] {
  return AMENITY_CATEGORIES.map((c) => {
    const st = index.categoryState(c);
    const within = st.state === 'UNAVAILABLE' ? [] : n.near[c].filter((x) => withinRadius(x.d, radius));
    const nearest = within[0] ? index.facilities[within[0].f] : null;
    const state = st.state === 'UNAVAILABLE' ? 'UNAVAILABLE' : within.length === 0 ? (st.state === 'AVAILABLE' ? 'NO_MATCH' : st.state) : st.state;
    return {
      category: c,
      matchedCount: st.state === 'UNAVAILABLE' ? 0 : within.length,
      nearest: nearest ? { id: nearest.id, name: nearest.name, distanceM: Math.round(within[0].d) } : null,
      state,
      stateReason:
        state === 'NO_MATCH'
          ? `No ${c.replace('_', ' ')} found within ${radius} m of the reference point.`
          : st.reason,
      provenance: st.provenance,
    };
  });
}

export function facilitiesNear(n: IndexedNeighbourhood, radius: ProximityRadius, category?: AmenityCategory): FacilityDto[] {
  const cats = category ? [category] : AMENITY_CATEGORIES;
  const out: FacilityDto[] = [];
  for (const c of cats) {
    if (index.categoryState(c).state === 'UNAVAILABLE') continue;
    for (const x of n.near[c]) {
      if (!withinRadius(x.d, radius)) break;
      const f = index.facilities[x.f];
      out.push({ id: f.id, name: f.name, category: f.category, address: f.address, lat: f.lat, lng: f.lng, distanceM: x.d, sourceId: f.sourceIds.join(', '), details: f.details });
    }
  }
  return out.sort((a, b) => a.distanceM - b.distanceM || a.name.localeCompare(b.name) || a.id.localeCompare(b.id)).map((f) => ({ ...f, distanceM: Math.round(f.distanceM) }));
}

export function neighbourhoodDetail(n: IndexedNeighbourhood, ctx: ScoringContext): NeighbourhoodDetail {
  if (ctx.origin) n = index.atPoint(n, ctx.origin);
  const boundarySource = index.sources.get('ura-subzones');
  return {
    id: n.id,
    name: n.name,
    planningArea: n.planningArea,
    region: n.region,
    lat: n.lat,
    lng: n.lng,
    boundaryBasis: `URA Master Plan 2019 subzone ${n.id} (${n.name}, ${n.planningArea} planning area).`,
    referencePointBasis: ctx.origin ? `Selected address: ${ctx.origin.address}. Straight-line great-circle distances from its coordinate; radius inclusion is checked before display rounding.` : `${n.boundaryBasis} ${DISTANCE_BASIS}`,
    boundary: n.boundary,
    radius: ctx.radius,
    amenities: amenitySummaries(n, ctx.radius),
    score: calculateScore(index.evidence(n, scoreThresholds(ctx), ctx.destinations), ctx.weights, index.datasetVersions()),
    provenance: boundarySource ? [boundarySource.provenance] : [],
    limitations: [ctx.origin ? 'Distances and amenity counts use the selected address, not the neighbourhood reference point.' : LIMITATION_PROFILE, LIMITATION_EDUCATION, LIMITATION_SCORE],
    origin: ctx.origin,
  };
}
