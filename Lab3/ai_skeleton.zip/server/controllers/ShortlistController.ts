// ==============================================================
//  ShortlistController.ts
//  Layer      : Controller
//  Owner      : Module 4 — Decision Support & Scoring
//  Description: Manages the shortlist and its notes for an account.
// ==============================================================
//
// Responsibilities
// TODO: Manage the shortlist and its notes for an account.
//
// Method stubs
// TODO: list(accountId): List<ShortlistEntry>
// TODO: add(accountId, neighbourhoodId): OperationResult
// TODO: remove(accountId, neighbourhoodId): OperationResult
// TODO: saveNote(accountId, neighbourhoodId, text): OperationResult
//
