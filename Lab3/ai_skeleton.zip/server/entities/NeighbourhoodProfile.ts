// ==============================================================
//  NeighbourhoodProfile.ts
//  Layer      : Entity
//  Owner      : Module 3 — Neighbourhood Map & Route
//  Description: Describes a neighbourhood, its area and data boundary.
// ==============================================================
//
// Responsibilities
// TODO: Describe a neighbourhood, its area and its data boundary.
//
// Data fields
// TODO: id: UUID
// TODO: name: String
// TODO: town: String
// TODO: planningArea: String
// TODO: boundaryBasis: String
//
// Method stubs
// TODO: describeCoverage(): String
// TODO: isDataStale(at, thresholdDays): Boolean
//
