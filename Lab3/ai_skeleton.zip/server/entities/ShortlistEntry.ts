// ==============================================================
//  ShortlistEntry.ts
//  Layer      : Entity
//  Owner      : Module 4 — Decision Support & Scoring
//  Description: A shortlisted neighbourhood and its attached note.
// ==============================================================
//
// Responsibilities
// TODO: Represent a shortlisted neighbourhood and its attached note.
//
// Data fields
// TODO: id: UUID
// TODO: addedAt: DateTime
//
// Method stubs
// TODO: attachNote(note): void
// TODO: clearNote(): void
//
