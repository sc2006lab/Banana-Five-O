// ==============================================================
//  Facility.ts
//  Layer      : Entity
//  Owner      : Module 3 — Neighbourhood Map & Route
//  Description: An amenity facility with category and source record identity.
// ==============================================================
//
// Responsibilities
// TODO: Represent an amenity facility with category and source-record identity.
//
// Data fields
// TODO: id: UUID
// TODO: name: String
// TODO: category: AmenityCategory
// TODO: address: String [0..1]
// TODO: sourceRecordId: String
// TODO: sourceUpdatedAt: DateTime [0..1]
//
// Method stubs
// TODO: hasUsableLocation(): Boolean
// TODO: hasSameIdentityAs(other): Boolean
//
