// ==============================================================
//  FamilySuitabilityScore.ts
//  Layer      : Entity
//  Owner      : Module 4 — Decision Support & Scoring
//  Description: Total suitability score with configuration and dataset provenance.
// ==============================================================
//
// Responsibilities
// TODO: Hold the total suitability score and its configuration and dataset provenance.
//
// Data fields
// TODO: total: Integer
// TODO: configurationVersion: String
// TODO: datasetVersions: Set<String>
// TODO: computedAt: DateTime
//
// Method stubs
// TODO: addBreakdown(item): void
// TODO: calculateTotal(): Integer
// TODO: contributionsReconcile(): Boolean
//
