// ==============================================================
//  UserAccount.ts
//  Layer      : Entity
//  Owner      : Module 1 — Account & Authentication
//  Description: Account, roles, status and login-lockout state of a user.
// ==============================================================
//
// Responsibilities
// TODO: Hold account identity, roles, status and failed-login lockout state.
//
// Data fields
// TODO: id: UUID
// TODO: displayName: String
// TODO: email: String
// TODO: roles: Set<UserRole>
// TODO: status: AccountStatus
// TODO: failedLoginAttempts: Integer
// TODO: lockedUntil: DateTime [0..1]
// TODO: deletedAt: DateTime [0..1]
//
// Method stubs
// TODO: recordFailedLogin(at): void
// TODO: clearFailedLogins(): void
// TODO: isLocked(at): Boolean
// TODO: hasRole(role): Boolean
// TODO: markDeleted(at): void
//
