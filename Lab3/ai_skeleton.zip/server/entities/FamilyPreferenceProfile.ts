// ==============================================================
//  FamilyPreferenceProfile.ts
//  Layer      : Entity
//  Owner      : Module 2 — Preferences & Discovery
//  Description: Family stages, preferred areas and saved preferences of an account.
// ==============================================================
//
// Responsibilities
// TODO: Hold the family stages, preferred areas and saved preferences of an account.
//
// Data fields
// TODO: familyStages: Set<FamilyStage>
// TODO: preferredAreas: Set<String>
// TODO: updatedAt: DateTime
//
// Method stubs
// TODO: setAmenityPreference(preference): void
// TODO: setCriterionWeight(weight): void
// TODO: addPriorityDestination(destination): void
// TODO: validate(): ValidationResult
//
