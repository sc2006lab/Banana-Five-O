// ==============================================================
//  SearchQuery.ts
//  Layer      : Entity
//  Owner      : Module 2 — Preferences & Discovery
//  Description: Criteria and sort option for a neighbourhood search.
// ==============================================================
//
// Responsibilities
// TODO: Hold neighbourhood search criteria and the requested sort option.
//
// Data fields
// TODO: searchText: String [0..1]
// TODO: area: String [0..1]
// TODO: familyStages: Set<FamilyStage>
// TODO: amenityCategories: Set<AmenityCategory>
// TODO: minimumFacilityCount: Integer [0..1]
// TODO: maximumDistance: ProximityRadius [0..1]
// TODO: commuteTimeThresholdMinutes: Integer [0..1]
// TODO: sortOption: SortOption
//
// Method stubs
// TODO: apply(profile): void
// TODO: validate(): ValidationResult
// TODO: hasContradictoryCriteria(): Boolean
//
