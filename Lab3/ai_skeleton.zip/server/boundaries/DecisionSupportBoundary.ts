// ==============================================================
//  DecisionSupportBoundary.ts
//  Layer      : Boundary
//  Owner      : Module 4 — Decision Support & Scoring
//  Description: UI adapter for scores, comparisons, shortlist actions and notes.
// ==============================================================
//
// Responsibilities
// TODO: Display suitability scores and neighbourhood comparisons.
// TODO: Capture comparison selection, shortlist actions and notes.
//
// Method stubs
// TODO: displayScore(score): void
// TODO: captureComparisonSelection(): NeighbourhoodComparisonSet
// TODO: displayComparison(comparison): void
// TODO: captureShortlistAction(): ShortlistAction
// TODO: captureNote(): String
//
